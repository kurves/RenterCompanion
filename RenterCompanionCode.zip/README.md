# RenterCompanion

A renter-side copilot that turns synthetic household documents into a human-confirmed profile, explains LIHTC (Low-Income Housing Tax Credit) rules with citations, flags missing or expired documents, and produces a renter-controlled application-readiness packet.

> **Design principle:** the AI extracts, explains, retrieves, calculates, and prepares. The renter confirms. A qualified human decides. RenterCompanion **never approves, denies, scores, ranks, or determines eligibility**.

---

## Scope

| Pillar | Choice |
| --- | --- |
| One metro | Boston-Cambridge-Newton, MA-NH HMFA |
| One program | LIHTC (Low-Income Housing Tax Credit) |
| One rule year | 2025 (corpus `lihtc-2025-04-boston-msa-v1`, effective 2025-04-01) |
| Documents | Synthetic only |
| Decisions | Human, off-platform |

---

## The three-stage flow

### 01 · Profile — human-confirmed extraction
Upload a synthetic pay stub or benefit letter (PDF) or paste text. The model extracts only allowlisted fields, each with a **verbatim source snippet** and a **calibrated confidence badge** (text + icon, never color-only). The renter must accept, reject, or edit each field before it is written to the profile.

### 02 · Understand — cited rules and deterministic math
Select an AMI set-aside (50 / 60 / 80%). The page shows the confirmed input, the threshold, the exact formula, the HUD source URL, the effective date, and the corpus version. If the city is not in the corpus or an input is missing, the page **abstains** rather than guessing. Under / over the limit — never "eligible".

### 03 · Prepare — renter-controlled packet
Preview the profile JSON, documents, and any missing or expired items against the gold checklist. Download the packet as JSON, edit fields, or delete it. RenterCompanion **never auto-sends** to a property or provider.

---

## Responsible-AI controls (live, not just disclaimers)

Everything below is exercised from the **Trust & controls** page in the app.

- **No decisioning** — hardened system prompt refuses "decide for me" and deflects to the rule, confirmed input, and calculation.
- **No hidden proxies** — every feature and its purpose is published in a transparency table. No demographic, behavioral, or landlord-revenue features.
- **Consent and correction** — every extracted value is correctable; consent, actions, and rule versions are logged locally (raw document contents are not).
- **Privacy and security** — synthetic documents, field allowlists, RLS-scoped Postgres, per-session deletion, JSON export. Uploads are never used for training.
- **Untrusted input** — document text is treated as data. Embedded instructions cannot alter tools, rules, or data access.
- **Live safety tests** — refusal, prompt-injection, and session-deletion tests run against the model on demand and show pass/fail with the model's verbatim reply.

### Discover (stretch)
Transparent LIHTC property listing for the Boston MSA. Availability is always labeled `unknown` unless separately supplied. Renter-selected filters only. No ranking, no protected-trait proxies.

---

## Tech stack

- **TanStack Start** (React 19, Vite 7) on Cloudflare Workers
- **Tailwind CSS v4** + shadcn/ui
- **Lovable Cloud** (Supabase Postgres with Row-Level Security) for auth, threads, messages, profiles, documents, and packets
- **Lovable AI Gateway** (`google/gemini-2.5-flash`) for chat, extraction, and multimodal PDF parsing
- **Lovable Assets CDN** for the logo and other static binaries

---

## Project structure

```
src/
  routes/
    __root.tsx                 metadata, SSR shell
    auth.tsx                   email + Google sign-in
    _authenticated/
      route.tsx                RLS-backed auth gate
      chat.index.tsx           welcome + design principles
      chat.$threadId.tsx       streaming chat with tool cards + citations
      profile.tsx              stage 01 — extraction + confirmation
      understand.tsx           stage 02 — cited rules + math
      documents.tsx            document library + LIHTC checklist
      packet.tsx               stage 03 — preview / download / delete
      discover.tsx             transparent property listing
      trust.tsx                feature transparency + live safety tests
      about.tsx                architecture & risk note
    api/chat.ts                streaming chat endpoint (AI Gateway)
  lib/
    lihtc-knowledge.ts         system prompt (hardened)
    lihtc-rules.ts             versioned corpus + deterministic math
    copilot.functions.ts       server functions (threads, extraction, packets)
    discover-data.ts           synthetic property set + feature purposes
    consent-log.ts             on-device consent/action log
```

---

## Local development

Requirements: [Bun](https://bun.sh).

```bash
bun install
bun run dev       # Vite dev server on http://localhost:8080
bun run build     # production build
```

Environment variables (`VITE_SUPABASE_URL`, `VITE_SUPABASE_PUBLISHABLE_KEY`, `VITE_SUPABASE_PROJECT_ID`) are provisioned automatically by Lovable Cloud. Server-only secrets (`LOVABLE_API_KEY`) are injected into the Cloudflare Worker runtime.

---

## Data model

| Table | Purpose |
| --- | --- |
| `threads` | Conversation metadata (title, program) |
| `messages` | Chat history per thread |
| `household_profiles` | One confirmed JSON profile per user |
| `documents` | Document metadata, type, expiration |
| `readiness_packets` | Snapshots of profile + document status |

Every table has RLS enabled and is scoped to `auth.uid()`. "Delete all my session data" wipes every RLS-scoped row plus the local consent log.

---

## Risks and mitigations

| Risk | Mitigation |
| --- | --- |
| Hallucinated rules | Versioned corpus, deterministic math, mandatory citations, abstain on unknowns |
| Wrong extraction | Confidence + source snippets, human accept/reject before any write |
| Prompt injection via documents | System prompt treats document text as data; live injection test on Trust page |
| Silent decisioning | Prompt refuses "decide for me"; UI labels are "under / over limit", never "eligible" |
| Data leakage | RLS, field allowlists, no training on uploads, one-click session deletion |

---

## License

Proprietary — all rights reserved.
